public class FormationIntrouvableException extends Exception {
    public FormationIntrouvableException(String message) {
        super(message);
    }
}
