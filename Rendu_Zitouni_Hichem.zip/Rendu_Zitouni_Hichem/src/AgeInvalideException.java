public class AgeInvalideException extends Exception {
    public AgeInvalideException(String message) {
        super(message);
    }
}
