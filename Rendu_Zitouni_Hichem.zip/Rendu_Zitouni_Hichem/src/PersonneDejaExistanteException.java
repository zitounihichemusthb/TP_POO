public class PersonneDejaExistanteException extends Exception {
    public PersonneDejaExistanteException(String message) {
        super(message);
    }
}
