public interface Inscription {
    void inscrire(String idFormation);
    void desinscrire(String idFormation);
}
