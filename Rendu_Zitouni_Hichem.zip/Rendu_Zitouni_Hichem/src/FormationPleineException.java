public class FormationPleineException extends Exception {
    public FormationPleineException(String message) {
        super(message);
    }
}
